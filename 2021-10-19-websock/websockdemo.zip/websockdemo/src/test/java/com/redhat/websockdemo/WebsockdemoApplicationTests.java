package com.redhat.websockdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebsockdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
