package com.redhat.websockdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebsockdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebsockdemoApplication.class, args);
	}

}
